# Is it real?

CKS is a Cognitive Learning Model, which is locked and emprically falsifiable.

The falsifications are not claims of truth, they are test of the applicability of the system to each domain.  

These are derived, locked equations, that match real world data to a high degree of accuracy across every domain, and therefore suitable as the Universal Learning Substrate for all physics-connected information.

## But, is it real?

As they said in Copenhagen: "Shut up and calculate."

Is it true?  No, but the model is isomorphic to reality.
